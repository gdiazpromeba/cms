<?php 

   interface DogSizesSvc { 

      public function selTodos($desde, $cuantos); 
      public function selTodosCuenta(); 
   } 

?>