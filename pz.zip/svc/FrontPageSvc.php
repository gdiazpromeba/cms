<?php 

   interface FrontPageSvc { 

      public function obtiene(); 
      public function actualiza($bean); 
   } 

?>