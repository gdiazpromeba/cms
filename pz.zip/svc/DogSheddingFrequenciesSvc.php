<?php 

   interface DogSheddingFrequenciesSvc { 

      public function selecciona($desde, $cuantos); 
      public function seleccionaCuenta(); 
   } 

?>