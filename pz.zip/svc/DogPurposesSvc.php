<?php 

   interface DogPurposesSvc { 

      public function selTodos($desde, $cuantos); 
      public function selTodosCuenta(); 
   } 

?>