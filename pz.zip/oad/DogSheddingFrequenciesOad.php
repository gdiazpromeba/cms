<?php 

   interface DogSheddingFrequenciesOad { 

      public function selecciona($desde, $cuantos); 
      public function seleccionaCuenta(); 
  } 

?>