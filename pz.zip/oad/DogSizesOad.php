<?php 

   interface DogSizesOad { 

      public function selTodos($desde, $cuantos); 
      public function selTodosCuenta(); 
  } 

?>