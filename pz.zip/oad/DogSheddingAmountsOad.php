<?php 

   interface DogSheddingAmountsOad { 

      public function selecciona($desde, $cuantos); 
      public function seleccionaCuenta(); 
  } 

?>