<?php 

   interface FrontPageOad { 

      public function obtiene(); 
      public function actualiza($bean); 
   } 

?>