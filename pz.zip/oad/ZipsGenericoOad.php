<?php 

   interface ZipsGenericoOad { 

      public function obtienePorCodigo($pais, $code);
      public function inserta($pais, $bean);
   } 

?>